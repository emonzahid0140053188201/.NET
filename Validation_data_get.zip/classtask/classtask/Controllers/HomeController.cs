﻿using classtask.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace classtask.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Home()
        {
            string name = "Zahid Hsan";
            string email = "zahidhasanaiubedu@gmail.com";
            string bio = "I am a student";

            ViewBag.name = name;
            ViewBag.email = email;
            ViewBag.bio = bio;

            return View();
        }

        public ActionResult MyProfile()
        {
            var Profile = new MyProfile();
            Profile.name = "Zahid Hasan";
            Profile.dob = "5/10/2001";
            Profile.nationality = "Bangladeshi";
            Profile.B_group = "0+ve";
            Profile.adress = "Pabna";
            Profile.contact_info = "012245";
            Profile.Hobbies = new string[] { "Travel", "gardening", "Sports" };



            return View(Profile);
        }

        public ActionResult Education()
        {
            MyEducation edu1 = new MyEducation();
            edu1.degree = "Bsc";
            edu1.Year = "2023";
            edu1.Ins = "AIUB";
            MyEducation edu2 = new MyEducation();
            edu2.degree = "Ssc";
            edu2.Year = "2017";
            edu2.Ins = "PZS";
            MyEducation edu3 = new MyEducation();
            edu3.degree = "Hsc";
            edu3.Year = "2019";
            edu3.Ins = "GEC";

            MyEducation[] myEducations = new MyEducation[] { edu1, edu2, edu3 };
            
            ViewBag.Edus = myEducations;

            return View();
        }
        public ActionResult Projects()
        {
            var p1 = new project();
            p1.course = "oop1";
            p1.description = "MS";

            var p2 = new project();
            p2.course = "WebTec";
            p2.description = "MS"; 
            
            var p3 = new project();
            p3.course = "c#";
            p3.description = "MS";
            var projects = new project[] { p1, p2, p3 };
            return View(projects);
        }
        public ActionResult Reference()
        {
            string name = "Arifur Rahman";
            string ocupation = "Teacher";
            string Degree = "Bsc in computer Science";

            ViewBag.name = name;
            ViewBag.ocupation = ocupation;
            ViewBag.degree = Degree;
            return View();
        }
    }
}