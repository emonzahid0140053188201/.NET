﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace classtask.Models
{
    public class project
    {
        public string course { set; get; }
        public string description { set; get; }
    }
}