﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace classtask.Models
{
    public class MyProfile
    {
        public string name { get; set; }
        public string dob { get; set; }
        public string nationality { get; set; }
        public string B_group { get; set; }

        public string adress { get; set; }
        public string contact_info { get; set; }
        public string[] Hobbies { get; set; }

    }
}