﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Zaro_Hunger.Models
{
    public class EmployeeDTO
    {
    }
}