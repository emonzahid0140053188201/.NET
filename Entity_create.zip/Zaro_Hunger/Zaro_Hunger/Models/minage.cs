﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Zaro_Hunger.Models
{
   
        public class minage : ValidationAttribute
        {
            protected override ValidationResult

                IsValid(object value, ValidationContext validationContext)
            {
                DateTime dob = Convert.ToDateTime(value);
                if (dob <= DateTime.Now.AddYears(-20))
                {
                    return ValidationResult.Success;

                }
                else
                {
                    return new ValidationResult
                        ("Dob must be uper 18");
                }
            }

        }
    }