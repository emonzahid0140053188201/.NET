﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Zaro_Hunger.Models
{
    public class ProductDTO
    {
        [Required]
        public int id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Preserve_Time { get; set; }
        [Required]
        public string Quantity { get; set; }
    }
}