﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Zaro_Hunger.Models
{
    public class UserDTO
    {
        public class UsetDTO
        {
            [StringLength(100)]
            [Required]
            [RegularExpression("^[A-Za-z. ]+$",
          ErrorMessage = "Please enter proper name")]

            public string name { get; set; }

            [StringLength(15)]
            [Required]
            [RegularExpression("^[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]*$", ErrorMessage = "Please enter proper name")]

            public string Uname { get; set; }
            [Required]
            public string Gender { get; set; }
            [Required]
            public string Profession { get; set; }

            [Required(ErrorMessage = ("Email fill empty"))]
            [RegularExpression("^\\d{2}-\\d{5}-\\d{1}@student\\.aiub\\.edu$",
            ErrorMessage = "Please enter proper email")]
            public string Email { get; set; }
            [Required]
            [minage]
            public DateTime dob { get; set; }
            [Required]
            [RegularExpression("^[0-9]{2}-[0-9]{5}-[1-3]$", ErrorMessage = "Must Follow:XX(0-9)-XXXX(0-9)-X(1-3)")]
            public string id { get; set; }
        }
    }
}
