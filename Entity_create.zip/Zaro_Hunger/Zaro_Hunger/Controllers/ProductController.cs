﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Zaro_Hunger.Models;

namespace Zaro_Hunger.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult food()
        {
            var db = new Product_EmployeeEntities();
            var data = db.Resturent_Product.ToList();
            return View(Convert(data));
        }

        [HttpGet]
        public ActionResult AddFood()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddFood(ProductDTO prod)
        {
            if (ModelState.IsValid)
            {
                var db = new Product_EmployeeEntities();
                db.Resturent_Product.Add(Convert(prod));
                db.SaveChanges();
                return RedirectToAction("food");


            }
            return View(prod);
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var db = new Product_EmployeeEntities();
            var products = db.Resturent_Product.Find(id);
            return View(Convert(products));
        }
        [HttpPost]
        public ActionResult Edit(ProductDTO pr)
        {
            var db = new Product_EmployeeEntities();
            var exp = db.Resturent_Product.Find(pr.id);
            exp.id = pr.id;
            exp.Name = pr.Name;
            exp.Preserve_Time = pr.Preserve_Time;
            exp.Ouantity = pr.Ouantity;
            db.SaveChanges();
            return RedirectToAction("food");

        }
        public ProductDTO Convert(Resturent_Product p)
        {
            var pr = new ProductDTO()
            {
                Name = p.Name,
                id = p.id,
                Preserve_Time = p.Preserve_Time,
                Ouantity = p.Ouantity,


            };
            return pr;
        }
        public Resturent_Product Convert(ProductDTO p)
        {
            var pr = new Resturent_Product()
            {
                Name = p.Name,
                id = p.id,
                Preserve_Time = p.Preserve_Time,
                Ouantity = p.Ouantity,


            };
            return pr;
        }
        List<ProductDTO> Convert(List<Resturent_Product> resturent_Product)
        {
            var ps = new List<ProductDTO>();
            foreach (var product in resturent_Product)
            {
                var p = Convert(product);
                ps.Add(p);
            }
            return ps;


        }
    }
}
}