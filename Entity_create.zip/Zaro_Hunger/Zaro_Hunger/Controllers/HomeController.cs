﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Zaro_Hunger.Models;

namespace Zaro_Hunger.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult SignUp()
        {

            return View();
        }
        [HttpPost]
        public ActionResult SignUp(UserDTO user)
        {
            if (ModelState.IsValid)
            {

                return View("Index");

            }
            return View(User);
        }
        public ActionResult Resturent()
        {

            return View();
        }
        public ActionResult NGO()
        {

            return View();
        }

    }
}

    
